export const publishArticle = () => {
  console.log('templet publishArticle');
};

export const deleteArticle = () => {
  console.log('templet deleteArticle');
};
