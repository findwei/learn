export function regUser() {
  console.log('templet regUser');
}
