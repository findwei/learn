import { publishArticle, deleteArticle } from './';

publishArticle();

deleteArticle();
