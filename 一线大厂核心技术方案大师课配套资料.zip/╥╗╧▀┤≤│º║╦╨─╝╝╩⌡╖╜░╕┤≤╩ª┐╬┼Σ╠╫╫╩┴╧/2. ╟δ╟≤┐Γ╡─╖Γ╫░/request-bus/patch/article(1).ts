export const publishArticle = () => {
  console.log('patch publishArticle');
};
